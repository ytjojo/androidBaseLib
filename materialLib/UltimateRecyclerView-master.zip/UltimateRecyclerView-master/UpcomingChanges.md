###Upcoming changes in 0.4.0:
- [x] add sticky header like instagram
- [ ] change an other sticky header for optimising
- [x] New recyclerview v22
- [ ] setSwipeToDismissCallback() throws a null pointer exception if there is no adapter set;
- [ ] trigger to bring the item back when swipe to dismiss
- [ ] auto judge loadmore or header in adatper
- [ ] swipe position judge
- [x] add method to set background color of recyclerview
- [x] add method to set default swipe to dismiss color
- [ ] add loading state of URV
- [ ] make ``swapAdapter`` more intelligent 
- [x] support different layout in UltimateViewAdapter
- [ ] Customize height and width
- [ ] Traditional header
- [ ] Swipe to dismiss color
 


###Other changes:
* More animations
* add swipe to refresh at the bottom
* etc...  




If you have some good idea, please tell us.My email is cymcsg # gmail.com.And it is a good idea to put your idea on the issue.
