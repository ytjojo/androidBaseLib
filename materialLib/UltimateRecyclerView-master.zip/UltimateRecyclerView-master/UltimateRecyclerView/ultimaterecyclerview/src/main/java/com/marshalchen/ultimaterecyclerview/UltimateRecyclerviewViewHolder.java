package com.marshalchen.ultimaterecyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.View;


/**
 * Created by MarshalChen on 15-6-2.
 */
public class UltimateRecyclerviewViewHolder extends RecyclerView.ViewHolder  {

    public UltimateRecyclerviewViewHolder(View itemView) {
        super(itemView);
    }


}