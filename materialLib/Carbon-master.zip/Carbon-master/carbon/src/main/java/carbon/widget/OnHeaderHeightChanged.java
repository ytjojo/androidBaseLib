package carbon.widget;

/**
 * Created by Marcin on 2015-05-17.
 */
public interface OnHeaderHeightChanged {
    void onHeightChanged(int height);
}
