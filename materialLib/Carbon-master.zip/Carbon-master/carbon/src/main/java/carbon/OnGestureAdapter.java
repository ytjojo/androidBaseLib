package carbon;

import android.view.MotionEvent;

/**
 * Created by Marcin on 2014-12-20.
 */
public class OnGestureAdapter implements OnGestureListener {

    @Override
    public void onPress(MotionEvent motionEvent) {
    }

    @Override
    public void onTap(MotionEvent motionEvent) {
    }

    @Override
    public void onDrag(MotionEvent motionEvent) {
    }

    @Override
    public void onMove(MotionEvent motionEvent) {
    }

    @Override
    public void onRelease(MotionEvent motionEvent) {
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {
    }

    @Override
    public void onMultiTap(MotionEvent motionEvent, int clicks) {
    }

    @Override
    public void onCancel(MotionEvent motionEvent) {
    }

}
