package carbon.beta;

import android.view.animation.Animation;

import static android.view.animation.Animation.AnimationListener;

/**
 * Created by Marcin on 2014-11-17.
 */
public class DefaultAnimationListener implements AnimationListener {
    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
