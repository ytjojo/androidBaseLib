package carbon.drawable;

/**
 * Created by Marcin on 2015-02-16.
 */
public interface RippleView {
    RippleDrawable getRippleDrawable();

    void setRippleDrawable(RippleDrawable rippleDrawable);
}
