package carbon.widget;

/**
 * Created by Marcin on 2015-04-18.
 */
public interface OnInsetsChangedListener {
    void onInsetsChanged();
}
