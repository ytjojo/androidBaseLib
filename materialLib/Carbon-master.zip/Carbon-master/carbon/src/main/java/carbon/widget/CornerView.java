package carbon.widget;

/**
 * Created by Marcin on 2015-04-23.
 */
public interface CornerView {
    int getCornerRadius();

    void setCornerRadius(int cornerRadius);
}
