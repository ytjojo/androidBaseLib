package carbon.widget;

import android.view.View;

/**
 * Created by Marcin on 2015-03-10.
 */
public interface TabBuilder {
    View getView(int position);
}
